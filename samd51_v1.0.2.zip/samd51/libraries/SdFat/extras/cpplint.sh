#! /usr/bin/bash
./cpplint.py ../src/*.cpp ../src/*.h ../src/*/*.cpp ../src/*/*.h  ../src/SdCard/*/*.cpp ../src/SdCard/*/*.h 2>cpplint.txt